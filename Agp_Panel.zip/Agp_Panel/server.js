const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const multer = require('multer');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(express.static('public'));

const MC_DIR = path.join(__dirname, 'minecraft_server');
if (!fs.existsSync(MC_DIR)) fs.mkdirSync(MC_DIR);

let mcProcess = null;

// File Upload Config
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, MC_DIR),
    filename: (req, file, cb) => cb(null, file.originalname)
});
const upload = multer({ storage });

// API: Upload File (For server.jar or plugins)
app.post('/api/upload', upload.single('file'), (req, res) => {
    res.json({ success: true, message: 'File uploaded successfully!' });
});

// API: File Manager List
app.get('/api/files', (req, res) => {
    try {
        const files = fs.readdirSync(MC_DIR).map(file => {
            const stats = fs.statSync(path.join(MC_DIR, file));
            return { name: file, isDirectory: stats.isDirectory(), size: stats.size };
        });
        res.json(files);
    } catch (err) {
        res.status(500).json([]);
    }
});

// API: Plugin Installer (Download from URL)
app.post('/api/plugins/install', async (req, res) => {
    const { url, name } = req.body;
    const pluginsDir = path.join(MC_DIR, 'plugins');
    if (!fs.existsSync(pluginsDir)) fs.mkdirSync(pluginsDir);
    
    try {
        const response = await axios({ url, method: 'GET', responseType: 'stream' });
        const writer = fs.createWriteStream(path.join(pluginsDir, name));
        response.data.pipe(writer);
        writer.on('finish', () => res.json({ success: true }));
        writer.on('error', () => res.status(500).json({ error: 'Download failed' }));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Live Console via WebSockets
io.on('connection', (socket) => {
    console.log('Admin connected to Agp Panel');
    
    socket.emit('console', '\n--- Welcome to Agp Panel ---\nSystem Ready.\n');
    
    socket.on('start', () => {
        if (mcProcess) return socket.emit('console', 'Server is already running.\n');
        
        const jarPath = path.join(MC_DIR, 'server.jar');
        if (!fs.existsSync(jarPath)) {
            return socket.emit('console', 'ERROR: server.jar not found! Please upload it via File Manager.\n');
        }
        
        // Auto-accept EULA
        fs.writeFileSync(path.join(MC_DIR, 'eula.txt'), 'eula=true\n');
        
        socket.emit('console', 'Starting Minecraft Server...\n');
        mcProcess = spawn('java', ['-Xmx2048M', '-Xms1024M', '-jar', 'server.jar', 'nogui'], { cwd: MC_DIR });
        
        mcProcess.stdout.on('data', (data) => socket.emit('console', data.toString()));
        mcProcess.stderr.on('data', (data) => socket.emit('console', data.toString()));
        
        mcProcess.on('close', (code) => {
            socket.emit('console', `Server stopped (Code: ${code})\n`);
            mcProcess = null;
        });
    });
    
    socket.on('command', (cmd) => {
        if (mcProcess) {
            mcProcess.stdin.write(cmd + '\n');
            socket.emit('console', `> ${cmd}\n`);
        } else {
            socket.emit('console', 'Server is offline. Cannot send command.\n');
        }
    });
    
    socket.on('stop', () => {
        if (mcProcess) mcProcess.stdin.write('stop\n');
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Agp Panel daemon running on port ${PORT}`);
});
