const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(express.static('public'));

// Servers data folder
const SERVERS_DIR = path.join(__dirname, 'servers');
if (!fs.existsSync(SERVERS_DIR)) fs.mkdirSync(SERVERS_DIR);

const activeServers = {};

// API: Naya Server Create Karna
app.post('/api/servers/create', (req, res) => {
    const { name, ram, port } = req.body;
    const uuid = Math.random().toString(36).substring(2, 10);
    const dir = path.join(SERVERS_DIR, uuid);
    
    fs.mkdirSync(dir);
    // Auto EULA accept aur port assign
    fs.writeFileSync(path.join(dir, 'server.properties'), `server-port=${port}\n`);
    fs.writeFileSync(path.join(dir, 'eula.txt'), 'eula=true\n');
    
    res.json({ success: true, uuid, name, ram, port });
});

// Live Console & Controls
io.on('connection', (socket) => {
    socket.on('power', ({ uuid, action, ram }) => {
        const dir = path.join(SERVERS_DIR, uuid);
        
        if (action === 'start') {
            if (activeServers[uuid]) return socket.emit('log', 'Server already running.\n');
            
            // Dummy jar check (Testing ke liye)
            const jarPath = path.join(dir, 'server.jar');
            if (!fs.existsSync(jarPath)) fs.writeFileSync(jarPath, 'Dummy Jar');

            const mc = spawn('java', [`-Xmx${ram}M`, '-jar', 'server.jar', 'nogui'], { cwd: dir });
            activeServers[uuid] = mc;
            
            socket.emit('log', 'Starting server process...\n');
            
            mc.stdout.on('data', data => socket.emit('log', data.toString()));
            mc.stderr.on('data', data => socket.emit('log', data.toString()));
            mc.on('close', () => {
                delete activeServers[uuid];
                socket.emit('log', 'Server Offline.\n');
            });
        } 
        else if (action === 'stop' && activeServers[uuid]) {
            activeServers[uuid].stdin.write('stop\n');
        }
        else if (action === 'kill' && activeServers[uuid]) {
            activeServers[uuid].kill();
        }
    });

    socket.on('command', ({ uuid, cmd }) => {
        if (activeServers[uuid]) {
            activeServers[uuid].stdin.write(cmd + '\n');
            socket.emit('log', `> ${cmd}\n`);
        }
    });
});

const PORT = 8080;
server.listen(PORT, () => {
    console.log(`[AGP Panel V2] Started on port ${PORT}`);
});
eula=true\n');
        
        socket.emit('console', 'Starting Minecraft Server...\n');
        mcProcess = spawn('java', ['-Xmx2048M', '-Xms1024M', '-jar', 'server.jar', 'nogui'], { cwd: MC_DIR });
        
        mcProcess.stdout.on('data', (data) => socket.emit('console', data.toString()));
        mcProcess.stderr.on('data', (data) => socket.emit('console', data.toString()));
        
        mcProcess.on('close', (code) => {
            socket.emit('console', `Server stopped (Code: ${code})\n`);
            mcProcess = null;
        });
    });
    
    socket.on('command', (cmd) => {
        if (mcProcess) {
            mcProcess.stdin.write(cmd + '\n');
            socket.emit('console', `> ${cmd}\n`);
        } else {
            socket.emit('console', 'Server is offline. Cannot send command.\n');
        }
    });
    
    socket.on('stop', () => {
        if (mcProcess) mcProcess.stdin.write('stop\n');
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Agp Panel daemon running on port ${PORT}`);
});
