# Agp Panel
Created by MD AAYAN RAZA

A lightweight, No-Docker Minecraft server panel. Built with Node.js, Express, and Tailwind CSS.
Perfect for running directly on a VPS, LXC containers, or testing in GitHub Codespaces!

## How to test in GitHub Codespaces

1. Extract this folder.
2. Open the terminal and run:
   ```bash
   npm install
   ```
3. Start the daemon panel:
   ```bash
   npm start
   ```
4. Codespaces will prompt to forward Port 3000. Open the provided web link.
5. Go to the **File Manager** tab and upload your `server.jar` (Paper, Spigot, or Vanilla).
6. Go back to the Console and click **Start**!

## Features
- No Docker Daemon required! Runs directly via Node.js `child_process`.
- Dark Mode sleek UI with Tailwind.
- File Uploader for server JAR and configs.
- Remote URL Plugin Installer.
- Live real-time WebSocket console.
