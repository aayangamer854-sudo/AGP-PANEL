Set DNS to the server, open TCP 80/443, then install with `DOMAIN=panel.example.com bash install.sh`. Caddy obtains and renews TLS and serves HTTPS.
