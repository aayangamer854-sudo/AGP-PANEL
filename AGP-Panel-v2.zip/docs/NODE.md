Native node agent runs independently of Docker/KVM/LXC/LXD. Production deployments should add authentication/mTLS before exposing node management.
