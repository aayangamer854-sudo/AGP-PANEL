#!/usr/bin/env bash
set -e
APP=/opt/agp-panel
DOMAIN="${DOMAIN:-}"
apt-get update -y
apt-get install -y python3 python3-venv python3-pip curl ca-certificates
mkdir -p "$APP"; cp -r "$(dirname "$0")/panel" "$APP/"
python3 -m venv "$APP/venv"
"$APP/venv/bin/pip" install -r "$APP/panel/requirements.txt"
cat >/etc/systemd/system/agp-panel.service <<EOF
[Unit]
Description=AGP Panel v2
After=network.target
[Service]
WorkingDirectory=$APP/panel
ExecStart=$APP/venv/bin/uvicorn app:app --host 127.0.0.1 --port 8080
Restart=always
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now agp-panel
if [ -n "$DOMAIN" ]; then
 apt-get install -y caddy
 cat >/etc/caddy/Caddyfile <<EOF
$DOMAIN {
 reverse_proxy 127.0.0.1:8080
}
EOF
 systemctl reload caddy || systemctl restart caddy
 echo "HTTPS: https://$DOMAIN"
else
 echo "Panel: http://SERVER_IP:8080"
fi
