# AGP Panel v2
Native Minecraft panel without Docker/KVM/LXC/LXD. HTTPS-ready with Caddy.

Install panel: `sudo bash install.sh` or `sudo DOMAIN=panel.example.com bash install.sh`
Install node: `sudo bash node-agent/install.sh`
