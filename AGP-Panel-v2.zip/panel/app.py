from fastapi import FastAPI, WebSocket
from fastapi.responses import HTMLResponse
from pathlib import Path
app=FastAPI(title="AGP Panel v2")
servers={}
@app.get("/",response_class=HTMLResponse)
def home(): return Path("static/index.html").read_text()
@app.get("/api/health")
def health(): return {"ok":True,"version":"v2"}
@app.get("/api/servers")
def list_servers(): return list(servers.values())
@app.post("/api/servers")
def create(data:dict):
 i=str(len(servers)+1); servers[i]={"id":i,"name":data.get("name","server-"+i),"version":data.get("version","1.21.11"),"status":"offline"}; return servers[i]
@app.post("/api/servers/{sid}/{action}")
def action(sid,action):
 if sid not in servers:return {"error":"not found"}
 if action in ("start","restart"):servers[sid]["status"]="online"
 if action in ("stop","kill"):servers[sid]["status"]="offline"
 return servers[sid]
@app.websocket("/ws/console/{sid}")
async def console(ws:WebSocket,sid):
 await ws.accept(); await ws.send_text("[AGP] Console connected")
 while True:
  try: await ws.send_text("> "+await ws.receive_text())
  except: break
