#!/usr/bin/env bash
set -e
apt-get update -y; apt-get install -y python3 python3-venv python3-pip
mkdir -p /opt/agp-node; cp -r "$(dirname "$0")"/* /opt/agp-node/
python3 -m venv /opt/agp-node/venv; /opt/agp-node/venv/bin/pip install fastapi uvicorn
cat >/etc/systemd/system/agp-node.service <<EOF
[Unit]
Description=AGP Native Node Agent
After=network.target
[Service]
WorkingDirectory=/opt/agp-node
ExecStart=/opt/agp-node/venv/bin/uvicorn agent:app --host 0.0.0.0 --port 9090
Restart=always
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload; systemctl enable --now agp-node
