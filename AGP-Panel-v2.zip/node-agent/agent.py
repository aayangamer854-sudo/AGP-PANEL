from fastapi import FastAPI
import platform,os,shutil
app=FastAPI(title="AGP Node Agent v2")
@app.get("/health")
def health():
 t,u,f=shutil.disk_usage("/"); return {"ok":True,"hostname":platform.node(),"cpu":os.cpu_count(),"disk_total":t,"disk_free":f}
