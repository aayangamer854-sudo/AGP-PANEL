#!/usr/bin/env bash
systemctl disable --now agp-panel 2>/dev/null || true
rm -f /etc/systemd/system/agp-panel.service
systemctl daemon-reload
rm -rf /opt/agp-panel
