#!/usr/bin/env bash
set -e

APP_NAME="agp-panel"
INSTALL_DIR="/opt/$APP_NAME"
SERVICE_NAME="agp-panel"

echo "=============================================="
echo "        AGP PANEL INSTALLER"
echo "=============================================="
echo
echo "1) Install AGP Panel"
echo "2) Update AGP Panel"
echo "3) Uninstall AGP Panel"
echo "4) Exit"
echo
read -rp "Choose an option (1-4): " OPTION

install_panel() {
    echo "[AGP] Installing panel..."

    if [ "$(id -u)" -ne 0 ]; then
        echo "[ERROR] Please run as root."
        exit 1
    fi

    apt-get update
    apt-get install -y python3 python3-venv python3-pip curl

    mkdir -p "$INSTALL_DIR"
    cp -r ./panel/* "$INSTALL_DIR/" 2>/dev/null || true
    cp -r ./node "$INSTALL_DIR/" 2>/dev/null || true
    cp -r ./config "$INSTALL_DIR/" 2>/dev/null || true

    cd "$INSTALL_DIR"

    python3 -m venv venv
    "$INSTALL_DIR/venv/bin/pip" install --upgrade pip
    if [ -f requirements.txt ]; then
        "$INSTALL_DIR/venv/bin/pip" install -r requirements.txt
    fi

    cat >/etc/systemd/system/$SERVICE_NAME.service <<EOF
[Unit]
Description=AGP Panel
After=network.target

[Service]
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/main.py
Restart=always
RestartSec=3
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable --now "$SERVICE_NAME"

    echo
    echo "[OK] AGP Panel installed."
    echo "[INFO] Panel: http://YOUR_SERVER_IP:8080"
}

update_panel() {
    if [ ! -d "$INSTALL_DIR" ]; then
        echo "[ERROR] AGP Panel is not installed."
        exit 1
    fi

    cp -r ./panel/* "$INSTALL_DIR/" 2>/dev/null || true
    cd "$INSTALL_DIR"
    "$INSTALL_DIR/venv/bin/pip" install -r requirements.txt 2>/dev/null || true
    systemctl restart "$SERVICE_NAME"
    echo "[OK] AGP Panel updated."
}

uninstall_panel() {
    if [ "$(id -u)" -ne 0 ]; then
        echo "[ERROR] Please run as root."
        exit 1
    fi

    read -rp "Delete AGP Panel and its data? Type YES: " CONFIRM
    if [ "$CONFIRM" != "YES" ]; then
        echo "Cancelled."
        exit 0
    fi

    systemctl disable --now "$SERVICE_NAME" 2>/dev/null || true
    rm -f "/etc/systemd/system/$SERVICE_NAME.service"
    systemctl daemon-reload
    rm -rf "$INSTALL_DIR"

    echo "[OK] AGP Panel removed."
}

case "$OPTION" in
    1) install_panel ;;
    2) update_panel ;;
    3) uninstall_panel ;;
    4) exit 0 ;;
    *) echo "Invalid option." ;;
esac
