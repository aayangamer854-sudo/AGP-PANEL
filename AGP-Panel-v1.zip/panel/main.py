from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import psutil

app = FastAPI(title="AGP Panel", version="1.0.0")

HTML = """
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AGP Panel</title>
<style>
body{margin:0;background:#080b14;color:#fff;font-family:Arial,sans-serif}
header{padding:22px 28px;background:#10172a;border-bottom:1px solid #26304a}
h1{margin:0;color:#61a8ff}
main{padding:28px;display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:18px}
.card{background:#111827;border:1px solid #26304a;border-radius:14px;padding:22px}
.label{color:#91a0bd;font-size:13px}.value{font-size:25px;margin-top:8px}
</style>
</head>
<body>
<header><h1>AGP PANEL</h1></header>
<main>
<div class="card"><div class="label">STATUS</div><div class="value">ONLINE</div></div>
<div class="card"><div class="label">CPU</div><div class="value">{cpu}%</div></div>
<div class="card"><div class="label">RAM</div><div class="value">{ram}%</div></div>
<div class="card"><div class="label">SERVERS</div><div class="value">0</div></div>
</main>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
def dashboard():
    return HTML.format(cpu=psutil.cpu_percent(interval=0.1),
                       ram=psutil.virtual_memory().percent)

@app.get("/api/health")
def health():
    return {"panel":"AGP Panel","status":"online","version":"1.0.0"}

@app.get("/api/resources")
def resources():
    return {
        "cpu_percent": psutil.cpu_percent(interval=0.1),
        "ram_percent": psutil.virtual_memory().percent,
        "disk_percent": psutil.disk_usage("/").percent
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
