# AGP Panel v1

Native Linux Minecraft hosting panel foundation.

## Requirements
- Ubuntu/Debian Linux
- Root access
- Python 3

## Install
```bash
chmod +x install.sh
sudo ./install.sh
```

Select option 1.

Panel listens on port 8080.
