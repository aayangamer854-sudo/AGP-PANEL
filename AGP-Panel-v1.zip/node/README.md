# AGP Node

This directory is reserved for the native AGP Node Agent.

Planned responsibilities:
- Minecraft process management
- console streaming
- file management
- backups
- resource monitoring
- node heartbeat
- server lifecycle controls

The first package intentionally does not execute arbitrary Minecraft commands.
