# AGP Panel configuration

Configuration files can be added here in later releases.
