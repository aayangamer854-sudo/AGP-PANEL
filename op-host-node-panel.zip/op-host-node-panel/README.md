# OP HOST Node.js Minecraft Panel

Docker-free native Minecraft panel using Node.js, Express and WebSocket.

Requirements: Debian/Ubuntu VPS, Node.js 18+, Java installed, and a Minecraft `server.jar`.

Install:
```bash
chmod +x install.sh && sudo ./install.sh
```

Default panel port: `6767`.

Each Minecraft server runs as a native Java child process. Docker and the Docker daemon are not used.

Before public exposure, put the panel behind HTTPS/reverse proxy and use a strong password.
