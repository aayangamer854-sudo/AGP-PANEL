#!/usr/bin/env bash
set -euo pipefail
APP=/opt/op-host-panel; USR=ophost; PORT=${PORT:-6767}
apt-get update && apt-get install -y curl ca-certificates openssl
if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 18 ]; then curl -fsSL https://deb.nodesource.com/setup_20.x | bash -; apt-get install -y nodejs; fi
id "$USR" >/dev/null 2>&1 || useradd --system --create-home --home-dir "$APP" --shell /usr/sbin/nologin "$USR"
mkdir -p "$APP"; cp -a . "$APP/"; mkdir -p "$APP/data" "$APP/servers"; chown -R "$USR:$USR" "$APP"
cd "$APP"; sudo -u "$USR" npm install --omit=dev
PW=$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | head -c 18); SEC=$(openssl rand -hex 32)
cat > "$APP/.env" <<E
PANEL_USER=admin
PANEL_PASSWORD=$PW
SESSION_SECRET=$SEC
PORT=$PORT
E
chmod 600 "$APP/.env"; chown "$USR:$USR" "$APP/.env"
cat >/etc/systemd/system/op-host-panel.service <<E
[Unit]
Description=OP HOST Node.js Minecraft Panel
After=network.target
[Service]
User=$USR
WorkingDirectory=$APP
EnvironmentFile=$APP/.env
ExecStart=$(command -v node) $APP/server.js
Restart=always
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
[Install]
WantedBy=multi-user.target
E
systemctl daemon-reload; systemctl enable --now op-host-panel
IP=$(hostname -I | awk '{print $1}')
echo "================================"; echo "OP HOST PANEL INSTALLED"; echo "URL: http://${IP}:$PORT"; echo "USER: admin"; echo "PASS: $PW"; echo "================================"; echo "Docker daemon is NOT used."
