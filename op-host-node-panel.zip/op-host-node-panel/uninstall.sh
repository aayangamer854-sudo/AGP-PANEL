#!/usr/bin/env bash
set -e
systemctl disable --now op-host-panel 2>/dev/null || true
rm -f /etc/systemd/system/op-host-panel.service
systemctl daemon-reload
echo 'Panel service removed. Files remain in /opt/op-host-panel'
